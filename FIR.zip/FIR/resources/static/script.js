// Add an event listener to the form for submission
document.getElementById("firForm").addEventListener("submit", function (event) {
    event.preventDefault();  // Prevent the form from submitting the traditional way

    // Collect form data
    const firNumber = document.getElementById("firNumber").value;
    const date = document.getElementById("date").value;
    const time = document.getElementById("time").value;
    const place = document.getElementById("place").value;
    const complainantName = document.getElementById("complainantName").value;
    const complainantAddress = document.getElementById("complainantAddress").value;
    const crimeDetails = document.getElementById("crimeDetails").value;
    const accusedDetails = document.getElementById("accusedDetails").value;
    const actionTaken = document.getElementById("actionTaken").value;

    // Prepare the data in JSON format
    const firData = {
        firNumber: firNumber,
        date: date,
        time: time,
        place: place,
        complainantName: complainantName,
        complainantAddress: complainantAddress,
        crimeDetails: crimeDetails,
        accusedDetails: accusedDetails || null,  // Optional field
        actionTaken: actionTaken
    };

    // Send the data to the backend API using fetch
    fetch("http://localhost:8080/api/firs", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(firData)
    })
    .then(response => response.json())  // Parse the response as JSON
    .then(data => {
        // Show confirmation message
        document.getElementById("confirmationMessage").style.display = "block";

        // Clear the form
        document.getElementById("firForm").reset();

        // Optional: Set a timeout to reset the confirmation message and show a new FIR form
        setTimeout(() => {
            document.getElementById("confirmationMessage").style.display = "none";
            document.getElementById("firForm").reset();  // Reset the form again if necessary
        }, 5000);  // Hide the confirmation message after 5 seconds
    })
    .catch(error => {
        console.error("Error submitting FIR:", error);
    });
});
