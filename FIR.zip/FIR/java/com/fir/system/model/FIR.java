package com.fir.system.model;

import jakarta.persistence.*;

@Entity
@Table(name = "fir_table1")
public class FIR {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String firNumber;
    private String date;
    private String time;
    private String place;
    private String complainantName;
    private String complainantAddress;
    private String crimeDetails;
    private String accusedDetails;
    private String actionTaken;

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getFirNumber() { return firNumber; }
    public void setFirNumber(String firNumber) { this.firNumber = firNumber; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }

    public String getPlace() { return place; }
    public void setPlace(String place) { this.place = place; }

    public String getComplainantName() { return complainantName; }
    public void setComplainantName(String complainantName) { this.complainantName = complainantName; }

    public String getComplainantAddress() { return complainantAddress; }
    public void setComplainantAddress(String complainantAddress) { this.complainantAddress = complainantAddress; }

    public String getCrimeDetails() { return crimeDetails; }
    public void setCrimeDetails(String crimeDetails) { this.crimeDetails = crimeDetails; }

    public String getAccusedDetails() { return accusedDetails; }
    public void setAccusedDetails(String accusedDetails) { this.accusedDetails = accusedDetails; }

    public String getActionTaken() { return actionTaken; }
    public void setActionTaken(String actionTaken) { this.actionTaken = actionTaken; }
}
