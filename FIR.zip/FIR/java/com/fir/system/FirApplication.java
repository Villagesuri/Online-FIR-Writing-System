package com.fir.system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirApplication {
    public static void main(String[] args) {
        SpringApplication.run(FirApplication.class, args);
    }
}

//http://localhost:8080/login