package com.fir.system.controller;

import com.fir.system.model.FIR;
import com.fir.system.repository.FIRRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/firs")
public class FIRController {

    @Autowired
    private FIRRepository firRepository;

    // API to file a new FIR
    @PostMapping
    public ResponseEntity<FIR> fileFIR(@RequestBody FIR fir) {
        try {
            FIR savedFIR = firRepository.save(fir);
            return new ResponseEntity<>(savedFIR, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // API to get all FIRs
    @GetMapping
    public ResponseEntity<List<FIR>> getAllFIRs() {
        try {
            List<FIR> firList = firRepository.findAll();
            return new ResponseEntity<>(firList, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // API to get an FIR by ID
    @GetMapping("/{id}")
    public ResponseEntity<FIR> getFIRById(@PathVariable Long id) {
        return firRepository.findById(id)
                .map(fir -> new ResponseEntity<>(fir, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // API to update an FIR
    @PutMapping("/{id}")
    public ResponseEntity<FIR> updateFIR(@PathVariable Long id, @RequestBody FIR updatedFIR) {
        return firRepository.findById(id).map(fir -> {
            fir.setFirNumber(updatedFIR.getFirNumber());
            fir.setDate(updatedFIR.getDate());
            fir.setTime(updatedFIR.getTime());
            fir.setPlace(updatedFIR.getPlace());
            fir.setComplainantName(updatedFIR.getComplainantName());
            fir.setComplainantAddress(updatedFIR.getComplainantAddress());
            fir.setCrimeDetails(updatedFIR.getCrimeDetails());
            fir.setAccusedDetails(updatedFIR.getAccusedDetails());
            fir.setActionTaken(updatedFIR.getActionTaken());
            FIR savedFIR = firRepository.save(fir);
            return new ResponseEntity<>(savedFIR, HttpStatus.OK);
        }).orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // API to delete an FIR
    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteFIR(@PathVariable Long id) {
        try {
            firRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
